package biggobushonrouth;

/*
Name : Biggo Bushon Routh
ID: 2012020310
Section: G
Email: cse_2012020310@lus.ac.bd
Date : 15.09.2021
*/
public class Main {

    public static void main(String[] args) {
        Player p = new Player("Shakib",75); 
        Cricket cricket = new Cricket("International match",20,p);
        cricket.display();
        Football football = new Football();
    }
}
