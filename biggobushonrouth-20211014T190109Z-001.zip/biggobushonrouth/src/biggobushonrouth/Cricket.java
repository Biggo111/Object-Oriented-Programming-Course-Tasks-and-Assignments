package biggobushonrouth;

/*
Name : Biggo Bushon Routh
ID: 2012020310
Section: G
Email: cse_2012020310@lus.ac.bd
Date : 15.09.2021
*/

public class Cricket extends Sports {

    String matchType;
    int over;
    Player player;

    public Cricket(String matchType, int over, Player player) {
        this.matchType = matchType;
        this.over = over;
        this.player = player;
    }
    void display(){
        System.out.println("Match Type: "+matchType);
        System.out.println("Over: "+over);
        System.out.println("Player Name: "+player.playerName);
        System.out.println("Jersey Number: "+player.jerseyNumber);
    }
}
